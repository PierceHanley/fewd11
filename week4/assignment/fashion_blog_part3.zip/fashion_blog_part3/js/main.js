"use strict";

$(document).ready(function() {
	// manipulate the page here if you want to make sure it only happens when
	// the page is initially loaded.
});